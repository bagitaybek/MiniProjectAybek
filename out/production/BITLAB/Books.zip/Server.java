import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class Server {
    static ArrayList<Book> books;
    static int id;
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        books = readFromFile();
        id = books.size()+1;
        ServerSocket server = new ServerSocket(2000);
        while(true) {
            Socket socket = server.accept();
            new ClientHandler(socket);
        }
    }
    public static void saveToFile() throws IOException {
        ObjectOutputStream fileOutputStream = new ObjectOutputStream(new FileOutputStream("Data.txt"));
        fileOutputStream.writeObject(books);
    }
    public static ArrayList<Book> readFromFile() throws IOException, ClassNotFoundException {
        ArrayList<Book> books = new ArrayList<>();
        if (new File("Data.txt").exists()){
            ObjectInputStream fileInputStream = new ObjectInputStream(new FileInputStream("Data.txt"));
            books = (ArrayList<Book>) fileInputStream.readObject();
        }
        return books;
    }
}

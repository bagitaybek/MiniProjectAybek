import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ClientHandler extends Thread {
    ObjectInputStream inputStream;
    ObjectOutputStream outputStream;
    public ClientHandler(Socket socket) throws IOException {
        inputStream = new ObjectInputStream(socket.getInputStream());
        outputStream = new ObjectOutputStream(socket.getOutputStream());
        start();
    }

    @Override
    public void run() {
        while(true){
            try {
                String request = (String) inputStream.readObject();
                if (request.equals("ADDBOOK")) {
                    Book book = (Book) inputStream.readObject();
                    book.id = Server.id;
                    Server.id++;
                    Server.books.add(book);
                    Server.saveToFile();
                    System.out.println("BOOK:"+book);
                }
                if (request.equals("LISTBOOKS")) {
                    outputStream.writeObject(Server.books.clone());
                    System.out.println("LIST SENT");
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }
}

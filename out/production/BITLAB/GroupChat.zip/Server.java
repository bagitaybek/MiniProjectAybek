import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class Server {
    static ArrayList<ClientHandler> clients = new ArrayList<>();
    public static void main(String[] args) throws IOException {
        ServerSocket server = new ServerSocket(2000);
        while(true){
            Socket socket = server.accept();
            clients.add(new ClientHandler(socket));
        }
    }
    public static void sendMessageToAllClients(String message) throws IOException {
        for (ClientHandler c : clients){
            c.showMessage(message);
        }
    }
}

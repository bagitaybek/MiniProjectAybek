import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ClientHandler extends Thread{
    ObjectInputStream inputStream;
    ObjectOutputStream outputStream;
    public ClientHandler(Socket socket) throws IOException {
        inputStream = new ObjectInputStream(socket.getInputStream());
        outputStream = new ObjectOutputStream(socket.getOutputStream());
        start();
    }

    @Override
    public void run() {
        while(true){
            try {
                String message = (String) inputStream.readObject();
                Server.sendMessageToAllClients(message);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }
    public void showMessage(String message) throws IOException {
        outputStream.writeObject(message);
    }
}

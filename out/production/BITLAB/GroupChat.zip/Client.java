import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) throws IOException {
        Scanner in = new Scanner(System.in);
        Socket socket = new Socket("192.168.1.129",2000);
        ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
        ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
        System.out.println("ENTER NAME: ");
        String name = in.nextLine();
        new Thread(new Runnable() { // отправка сообщении
            @Override
            public void run() {
                while(true){
                    try {
                        String message = in.nextLine();
                        outputStream.writeObject(name+": "+message);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
        new Thread(new Runnable() { // принятие сообщении
            @Override
            public void run() {
                try {
                    while(true) {
                        System.out.println(inputStream.readObject());
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }
        }).start();
        while(true){}
    }
}
